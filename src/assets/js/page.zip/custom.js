/**
 *
 * You can write your JS code here, DO NOT touch the default style file
 * because it will make it harder for you to update.
 * 
 */

 "use strict";

 google.charts.load('current', {'packages':['gauge']});
 google.charts.setOnLoadCallback(drawChart);

 function drawChart() {

  var data = google.visualization.arrayToDataTable([
    ['Label', 'Value'],
    ['Dev', 55],
    ['UI / UX', 68]
    ]);

  var options = {
    width: 500, height: 500,
    minorTicks: 5
};

var chart = new google.visualization.Gauge(document.getElementById('chart_div'));

chart.draw(data, options);

setInterval(function() {
    data.setValue(0, 1, 40 + Math.round(60 * Math.random()));
    chart.draw(data, options);
}, 13000);
setInterval(function() {
    data.setValue(1, 1, 40 + Math.round(60 * Math.random()));
    chart.draw(data, options);
}, 5000);
}



/*******************
Data Table
*******************/
$(document).ready(function() {
    $('.customDataTable').DataTable();
    $(".colorpickerinput").colorpicker({
      format: 'hex',
      component: '.input-group-append',
  });


/********************
Chat Widget Position
************************/

/********************
Chat Widget Position
************************/
$("#window-flat-chat").addClass("hide-block");
$(".widget-appearance-round-click").click(function() {
   $("#window-round-chat").addClass("show-block");
   $("#window-round-chat").removeClass("hide-block");
   $("#window-flat-chat").addClass("hide-block");
});
$(".widget-appearance-flat-click").click(function() {
   $("#window-round-chat").addClass("hide-block");
   $("#window-flat-chat").removeClass("hide-block");
   $("#window-flat-chat").addClass("show-block");
});

$(".chat-widget-position-1").click(function() {
    $(".widget-appearance-round, .widget-flat, .grabber-img").removeAttr("id");
    $(".widget-appearance-round").attr("id","bottom-left-round");
    $(".widget-flat").attr("id","bottom-left-flat");
    $(".grabber-img").attr("id","grabber-bottom-left");
});

$(".chat-widget-position-2").click(function() {
    $(".widget-appearance-round, .widget-flat, .grabber-img").removeAttr("id");
    $(".widget-appearance-round").attr("id","top-left-round");
    $(".widget-flat").attr("id","top-left-flat");
    $(".grabber-img").attr("id","grabber-top-left");
});

$(".chat-widget-position-3").click(function() {
 $(".widget-appearance-round, .widget-flat, .grabber-img").removeAttr("id");
 $(".widget-appearance-round").attr("id","top-right-round");
 $(".widget-flat").attr("id","top-right-flat");
 $(".grabber-img").attr("id","grabber-top-right");
});

$(".chat-widget-position-4").click(function() {
    $(".widget-appearance-round, .widget-flat, .grabber-img").removeAttr("id");
    $(".widget-appearance-round").attr("id","bottom-right-round");
    $(".widget-flat").attr("id","bottom-right-flat");
    $(".grabber-img").attr("id","grabber-bottom-right");
});

/**************
Slider Range
****************/
$(".slider-range").slider({
    range: true,
    min: 0,
    max: 1440,
    step: 15,
    values: [600, 720],
    slide: function (e, ui) {
        var hours1 = Math.floor(ui.values[0] / 60);
        var minutes1 = ui.values[0] - (hours1 * 60);

        if (hours1.length == 1) hours1 = '0' + hours1;
        if (minutes1.length == 1) minutes1 = '0' + minutes1;
        if (minutes1 == 0) minutes1 = '00';
        if (hours1 >= 12) {
            if (hours1 == 12) {
                hours1 = hours1;
                minutes1 = minutes1 + " PM";
            } else {
                hours1 = hours1 - 12;
                minutes1 = minutes1 + " PM";
            }
        } else {
            hours1 = hours1;
            minutes1 = minutes1 + " AM";
        }
        if (hours1 == 0) {
            hours1 = 12;
            minutes1 = minutes1;
        }
        $('.slider-time').html(hours1 + ':' + minutes1);
        var hours2 = Math.floor(ui.values[1] / 60);
        var minutes2 = ui.values[1] - (hours2 * 60);
        if (hours2.length == 1) hours2 = '0' + hours2;
        if (minutes2.length == 1) minutes2 = '0' + minutes2;
        if (minutes2 == 0) minutes2 = '00';
        if (hours2 >= 12) {
            if (hours2 == 12) {
                hours2 = hours2;
                minutes2 = minutes2 + " PM";
            } else if (hours2 == 24) {
                hours2 = 11;
                minutes2 = "59 PM";
            } else {
                hours2 = hours2 - 12;
                minutes2 = minutes2 + " PM";
            }
        } else {
            hours2 = hours2;
            minutes2 = minutes2 + " AM";
        }

        $('.slider-time2').html(hours2 + ':' + minutes2);
    }
});

});